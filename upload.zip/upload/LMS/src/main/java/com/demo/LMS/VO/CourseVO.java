package com.demo.LMS.VO;

import javax.validation.constraints.Size;

import com.sun.istack.NotNull;

public class CourseVO {
	private Long course_id;

	@NotNull
	@Size(min = 20, max = 255)
	private String course_name;

	@NotNull
	private Long course_duration;

	@NotNull
	@Size(min = 100, max = 255)
	private String course_description;

	@NotNull
	private String technology;

	@NotNull
	private String launch_url;

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public Long getCourse_duration() {
		return course_duration;
	}

	public void setCourse_duration(Long course_duration) {
		this.course_duration = course_duration;
	}

	public String getCourse_description() {
		return course_description;
	}

	public void setCourse_description(String course_description) {
		this.course_description = course_description;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getLaunch_url() {
		return launch_url;
	}

	public void setLaunch_url(String launch_url) {
		this.launch_url = launch_url;
	}

	public Long getCourse_id() {
		return course_id;
	}

	public void setCourse_id(Long course_id) {
		this.course_id = course_id;
	}

}
