package com.demo.LMS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.LMS.Entity.Course;
import com.demo.LMS.Service.CourseService;
import com.demo.LMS.VO.CourseVO;

@RequestMapping("/api/v1.0/lms/courses")
@RestController
public class CourseController {
	@Autowired
	private CourseService courseService;

	@PostMapping("/add/{course_name}")
	public ResponseEntity<?> addCourse(@RequestBody CourseVO courseVo,
			@PathVariable("course_name") String course_name) {
		return courseService.addCourse(courseVo, course_name);
	}

	@GetMapping("/getall")
	public List<Course> getAllCourses() {
		return courseService.getCourseDetails(null);
	}

	@GetMapping("/info/{technology}")
	public List<Course> getCoursesByTechnology(@PathVariable("technology") String technology) {
		return courseService.getCourseDetails(technology);
	}

	@DeleteMapping("/delete/{course_name}")
	public ResponseEntity<?> deleteCourse(@PathVariable("course_name") String course_name) {
		System.out.println(course_name);
		return courseService.deleteCourse(course_name);
	}

	@GetMapping("/get/{technology}/{from_duration}/{to_duration}")
	public List<Course> getCoursesByTechnologyAndDuration(@PathVariable("technology") String technology,
			@PathVariable("from_duration") long from_duration, @PathVariable("to_duration") long to_duration) {
		return courseService.getCourseDetailsByDuration(technology, from_duration, to_duration);
	}
}
