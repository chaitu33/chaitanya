package com.demo.UserManagement.Controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.UserManagement.Entity.LoginVO;
import com.demo.UserManagement.Entity.SignUpVO;
import com.demo.UserManagement.Repository.UserRepository;
import com.demo.UserManagement.Service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@RequestMapping("api/v1.0/lms/company")
public class AuthenticationController {
	@Autowired
	private UserService userservice;
	@Autowired
	private UserRepository userRepo;

	private Map<String, String> map = new HashMap<>();

	@PostMapping("/login")
	public ResponseEntity<?> userLogin(@Valid @RequestBody LoginVO user) {
		try {
			String jwtToken = generateToken(user.getUsername(), user.getPassword());
			map.put("message", "successful login");
			map.put("token", jwtToken);
			map.put("role", userRepo.getRole(user.getUsername()));
		} catch (Exception e) {
			map.put("message", "unsuccessful login");
			map.put("token", null);
			return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	private String generateToken(String username, String password) throws Exception {
		String jwtToken = "";
		if (username == null || password == null) {
			throw new Exception("Please Provide valid credentials!");
		} else if (userservice.validateUser(username, password)) {
			jwtToken = Jwts.builder().setSubject(username).setIssuedAt(new Date())
					.setExpiration(new Date(System.currentTimeMillis() + (1000 * 60 * 60)))
					.signWith(SignatureAlgorithm.HS256, "FSE2LMS").compact();

		} else {
			throw new Exception("Wrong credentials!");
		}
		return jwtToken;

	}

	@PostMapping("/register")
	public ResponseEntity<?> signup(@Valid @RequestBody SignUpVO signupVo) {
		return userservice.signUp(signupVo);
	}

}
