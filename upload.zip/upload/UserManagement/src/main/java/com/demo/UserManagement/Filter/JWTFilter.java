package com.demo.UserManagement.Filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.filter.GenericFilterBean;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

public class JWTFilter extends GenericFilterBean {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		String authHeader = httpRequest.getHeader("authorization");
		if (authHeader == null || !authHeader.startsWith("FSE2LMS")) {
			throw new ServletException("Missing or invallid authorization header");
		}
		String jwtToken = authHeader.substring(8);
		System.out.println("Headers:" + authHeader);

		Claims claim = Jwts.parser().setSigningKey("FSE2LMS").parseClaimsJws(jwtToken).getBody();
		httpRequest.setAttribute("username", claim);

		chain.doFilter(request, response);

	}

}