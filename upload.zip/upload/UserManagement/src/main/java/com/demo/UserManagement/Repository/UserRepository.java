package com.demo.UserManagement.Repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.demo.UserManagement.Entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {

	@Query(value = "select * from user where user_name=(?1) and password=(?2)", nativeQuery = true)
	public User validateUser(String username, String password);

	@Query(value = "select count(*) from user where user_name=(?1)", nativeQuery = true)
	public long getUserNameCount(String username);

	@Query(value = "select count(*) from user where email=(?1)", nativeQuery = true)
	public long getEmailCount(String email);

	@Query(value = "select role from user where user_name=(?1)", nativeQuery = true)
	public String getRole(String user_name);

}
