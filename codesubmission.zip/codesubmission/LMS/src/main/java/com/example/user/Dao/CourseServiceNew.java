package com.example.user.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.user.Model.CourseInfo;
import com.example.user.Model.CourseVO;
import com.example.user.Repository.CourseRepositoryNew;

@Service
public class CourseServiceNew {
	
	@Autowired
	private CourseRepositoryNew courseRepo;
	
	public ResponseEntity<?> addCourse(CourseVO course){
		if(courseRepo.getCourseCount(course.getCourseName())!=0) {
			return ResponseEntity.badRequest().body(new String("ERROR : course already exist"));
		}
		else {
			CourseInfo newCourse=new CourseInfo(course.getCourseName(),course.getCourseDescription(),course.getCourseTechnology(),course.getCourseURL(),course.getCourseDuration());
			courseRepo.save(newCourse);
			return ResponseEntity.ok().body(new String("course added successfully"));
		}
	}
	
	public List<CourseInfo> getCourseDetails(String courseTechnology){
		List<CourseInfo> courses=null;
		if(courseTechnology!=null) {
			courses=(List<CourseInfo>) courseRepo.getCourseByTechnology(courseTechnology);
		}
		else {
			courses=(List<CourseInfo>) courseRepo.findAll();
		}
		return courses;
	}
	
	public List<CourseInfo> getCourseDetailsByDuration(String courseTechnology, long from_duration,long to_duration ){
		System.out.println("duration part : "+"tech : "+courseTechnology+" from :  "+from_duration+" to :  "+to_duration);
		return courseRepo.getCoursesByDuration(courseTechnology, from_duration, to_duration);
	}
	public ResponseEntity<?> deleteCourse(String courseName){
		System.out.println("in service :course name : "+courseName);
		Long course_id=courseRepo.getCourseId(courseName);
		System.out.println("course id is : "+course_id);
		if(course_id!=null) {
			courseRepo.deleteById(course_id);
			return ResponseEntity.ok().body(new String ("course deleted successfully"));
		}
		else
		{
			return ResponseEntity.badRequest().body(new String("ERROR : course does not exist"));
		}
	}
}
