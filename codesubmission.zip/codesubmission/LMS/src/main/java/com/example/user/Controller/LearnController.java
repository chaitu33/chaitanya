package com.example.user.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.user.Dao.CourseService;
import com.example.user.Dao.CourseServiceNew;
import com.example.user.Model.CourseInfo;
import com.example.user.Model.CourseVO;
import com.example.user.Repository.CourseRepository;

@RestController
@RequestMapping("api/v1.0/lms/courses")
public class LearnController {

	
	@Autowired
	private CourseService courseService;
	@Autowired
	private CourseServiceNew courseServiceNew;
	@PostMapping(value="/new", consumes="application/json; charset-utf-8")
	public ResponseEntity<?> addNew(@RequestBody CourseInfo courseInfo)
	{
		if( courseService.addCourse(courseInfo)!=null) {
			return new ResponseEntity<CourseInfo>(courseInfo,HttpStatus.CREATED);
			
		}
		return new ResponseEntity<String>("record not created",HttpStatus.CONFLICT);
	}
	@GetMapping("/getAllDetails")
	public ResponseEntity<?> getAllCourses(){
		List<CourseInfo> courseList=courseService.getAllCourses();
		if (courseList!=null) {
			return new ResponseEntity<List<CourseInfo>>(courseList,HttpStatus.OK);
		}
		return new ResponseEntity<String>("no courses",HttpStatus.NO_CONTENT);		
	}
	/*
	@DeleteMapping("/deleteold/{courseTech}")
	public ResponseEntity<?> deleteCourses(@PathVariable("courseTech") String courseTech){
		if(courseService.deleteCourse(courseTech)) {
			return new ResponseEntity<String>("course deleted",HttpStatus.NO_CONTENT);
			
		}
		return new ResponseEntity<String>("course could not be deleted", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@DeleteMapping("/deleteoneold/{courseTech}")
	public ResponseEntity<?> deleteCoursesByID(@PathVariable("courseTech") Long courseTech){
		if(courseService.deleteCoursebyID(courseTech)) {
			return new ResponseEntity<String>("course deleted",HttpStatus.NO_CONTENT);
			
		}
		return new ResponseEntity<String>("course could not be deleted", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping("getoneCourseold/{courseId}")
	public ResponseEntity<?> getOneCourse(@PathVariable("courseId") Long courseId){
		CourseInfo courseListst=courseService.searchCourse(courseId);
		if(courseListst!=null) {
			return new ResponseEntity<CourseInfo>(courseListst,HttpStatus.OK);
		}
		return new ResponseEntity<String>("no course",HttpStatus.NO_CONTENT);
	}
	*/
//new add ---------------------------------------------------------------------------
	@PostMapping("/add/{courseName}")
	public ResponseEntity<?> adCourseOne(@Valid @RequestBody CourseVO courseVo, @Valid @PathVariable("courseName") String courseName){
		return courseServiceNew.addCourse(courseVo);
	}
	
	@GetMapping("/getall")
	public List<CourseInfo> getAllCoursesNew(){
		return courseServiceNew.getCourseDetails(null);
	}
	@GetMapping("/info/{courseTechnology}")
	public List<CourseInfo> getCoursesByTechnology(@Valid @PathVariable("courseTechnology") String courseTechnology){
		return courseServiceNew.getCourseDetails(courseTechnology);
	}
	
	@DeleteMapping("/delete/{courseName}")
	public ResponseEntity<?> deleteCourse(@Valid @PathVariable("courseName") String courseName){
		System.out.println("course name for delete operation "+courseName);
		return courseServiceNew.deleteCourse(courseName);
	}
	@GetMapping("/get/{courseTechnology}/{from_duration}/{to_duration}")
	public List<CourseInfo> getCourseByTechnologyAndDuration
	(@Valid @PathVariable("courseTechnology") String courseTechnology,
			@Valid @PathVariable("from_duration") long from_duration,
			@Valid @PathVariable("to_duration") long to_duration)
	{
		return courseServiceNew.getCourseDetailsByDuration(courseTechnology, from_duration, to_duration);
	}
	
}
