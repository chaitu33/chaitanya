package com.example.user.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.user.Model.CourseInfo;
@Repository
public interface CourseRepository extends JpaRepository<CourseInfo, Long> {

 @Query(value="delete from course_info ud where ud.course_technology LIKE %:courseTech%",nativeQuery=true)
public boolean deleteStk(String courseTech);

//@Query(value="delete from CourseInfo u where u.courseTech = : courseTechnology")
	//public boolean deleteStk(String courseTech);
 @Query(value="select * from course_info u where u.course_code =?1", nativeQuery=true)
 public CourseInfo findonecourse(Long courseCode);
}
