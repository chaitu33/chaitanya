package com.example.user.Model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CourseVO {
	@NotNull
	@Size(min=2,max=255)
	private String courseName;
	@NotNull
	@Size(min=2,max=255)
	private String courseDescription;
	@NotNull
	private String courseTechnology;
	@NotNull
	private String courseURL;
	@NotNull
	private Long courseDuration;
	
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCourseDescription() {
		return courseDescription;
	}
	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}
	public String getCourseTechnology() {
		return courseTechnology;
	}
	public void setCourseTechnology(String courseTechnology) {
		this.courseTechnology = courseTechnology;
	}
	public String getCourseURL() {
		return courseURL;
	}
	public void setCourseURL(String courseURL) {
		this.courseURL = courseURL;
	}
	public Long getCourseDuration() {
		return courseDuration;
	}
	public void setCourseDuration(Long courseDuration) {
		this.courseDuration = courseDuration;
	}

}
