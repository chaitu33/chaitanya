package com.example.user.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.user.Model.CourseInfo;

public interface CourseRepositoryNew extends CrudRepository<CourseInfo, Long>{

	@Query(value="select * from course_info where course_technology=(?1)", nativeQuery=true)
	public List<CourseInfo> getCourseByTechnology(String courseTechnology );
	
	@Query(value="select * from course_info where course_technology=(?1) and course_duration>(?2) and course_duration<(?3)",nativeQuery=true)
	public List<CourseInfo> getCoursesByDuration(String courseTechnology,long from_duration , long to_duration );
	
	@Query(value="select count(*) from course_info where course_name=(?1)",nativeQuery=true)
	public long getCourseCount(String courseName);
	
	@Query(value="select course_code from course_info where course_name=(?1)", nativeQuery=true)
	public Long getCourseId(String courseName );
}
