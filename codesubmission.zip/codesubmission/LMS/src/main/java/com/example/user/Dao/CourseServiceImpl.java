package com.example.user.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.Model.CourseInfo;
import com.example.user.Repository.CourseRepository;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository courseRepository;

	@Override
	public CourseInfo addCourse(CourseInfo courseInfo) {
		// TODO Auto-generated method stub
		if(courseInfo!=null) {
			return courseRepository.save(courseInfo);
		}
		else
		return null;
	}

	@Override
	public List<CourseInfo> getAllCourses() {
		// TODO Auto-generated method stub
		List<CourseInfo> courseList=courseRepository.findAll();
		if(courseList!=null && courseList.size()>0) {
			return courseList;
		}
		else
		return null;
	}

	@Override
	public boolean deleteCourse(String courseTech) {
		// TODO Auto-generated method stub
		System.out.println("course tech : "+courseTech);
		boolean b1=courseRepository.deleteStk(courseTech);
		System.out.println("value of b1 : ");
		if(b1==true) {
			return true;
		}
		else
		return false;
	}

	@Override
	public boolean deleteCoursebyID(Long courseTech) {
		// TODO Auto-generated method stub
		courseRepository.deleteById(courseTech);
		return true;
	}

	@Override
	public CourseInfo searchCourse(Long courseId) {
		// TODO Auto-generated method stub
		Long courseCode=courseId;
		System.out.println("course ID is :"+courseCode);
		CourseInfo coursell=courseRepository.findonecourse(courseCode);
		if(coursell!=null) {
			return coursell;
		}
		else
		return null;
	}

	
	
	
	

}
