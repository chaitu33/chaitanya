package com.example.user.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class CourseInfo {

     @Id
     @Column
     @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long courseCode;
     public CourseInfo(String courseName, String courseDescription, String courseTechnology, String courseURL,
			Long courseDuration) {
		this.courseName = courseName;
		this.courseDescription = courseDescription;
		this.courseTechnology = courseTechnology;
		this.courseURL = courseURL;
		this.courseDuration = courseDuration;
	}
	public CourseInfo() {
		// TODO Auto-generated constructor stub
	}
	@Column
	private String courseName;
     @Column
	private String courseDescription;
     @Column
	private String courseTechnology;
     @Column
	private String courseURL;
     @Column
	private Long courseDuration;
	
	public Long getCourseDuration() {
		return courseDuration;
	}
	public void setCourseDuration(Long courseDuration) {
		this.courseDuration = courseDuration;
	}
	public Long getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(Long courseCode) {
		this.courseCode = courseCode;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCourseDescription() {
		return courseDescription;
	}
	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}
	public String getCourseTechnology() {
		return courseTechnology;
	}
	public void setCourseTechnology(String courseTechnology) {
		this.courseTechnology = courseTechnology;
	}
	public String getCourseURL() {
		return courseURL;
	}
	public void setCourseURL(String courseURL) {
		this.courseURL = courseURL;
	}
	
	
}
