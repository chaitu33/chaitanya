package com.example.user.Dao;

import java.util.List;

import com.example.user.Model.CourseInfo;

public interface CourseService {
 
	public CourseInfo addCourse(CourseInfo courseInfo);
	public List<CourseInfo> getAllCourses();
	public boolean deleteCourse(String courseTech);
	public boolean deleteCoursebyID(Long courseTech);
	public CourseInfo searchCourse(Long courseId);
}
