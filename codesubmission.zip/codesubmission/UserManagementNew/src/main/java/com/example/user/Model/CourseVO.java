package com.example.user.Model;

public class CourseVO {

}
