package com.example.user.Dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.user.Model.User;
import com.example.user.Repository.UserRepository;

@Service
public class UserServiceImpl  implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		List<User> userList=userRepository.findAll();
		if(userList!=null && userList.size()>0) {
			return userList;
		}
		else
		return null;
	}

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		if(user!=null) {
			return userRepository.saveAndFlush(user);
		}
		return null;
	}

	@Override
	public boolean validateUser(String username, String password) {
		// TODO Auto-generated method stub
		System.out.println("inside validating method :: ");
		User user=userRepository.validateUser(username, password);
		if(user!=null) {
			return true;
		}
		return false;
	}

}
